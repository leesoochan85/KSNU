package com.example.a2100998_0930a;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.Switch;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        EditText editText = (EditText) findViewById(R.id.editTextText);
        RadioButton radioButton = (RadioButton) findViewById(R.id.radioButton);
        RadioButton radioButton2 = (RadioButton) findViewById(R.id.radioButton2);
        Button button = (Button) findViewById(R.id.button);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (radioButton.isChecked()) {
                    double ct = Double.valueOf(editText.getText().toString());
                    double ft = ((ct * 9) / 5) + 32.0;
                    editText.setText(String.valueOf(ft));
                } else if (radioButton2.isChecked()) {
                    double ft = Double.valueOf(editText.getText().toString());
                    double ct = ((ft - 32) * 5) / 9;
                    editText.setText(String.valueOf(ct));
                } else {
                    Toast.makeText(getApplicationContext(),
                            "화씨 또는 섭씨를 선택해 주세요",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });

        ImageView imageView = (ImageView) findViewById(R.id.imageView);
        Switch swbutton = (Switch) findViewById(R.id.switch1);

        swbutton.setOnchec
    }
}
