package com.example.b2201024_0919b;

public class Random {
    public int nextInt(int i) {
        return 0;
    }
}
