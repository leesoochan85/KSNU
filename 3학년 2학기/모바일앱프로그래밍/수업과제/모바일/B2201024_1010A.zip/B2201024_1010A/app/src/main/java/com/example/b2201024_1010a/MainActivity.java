package com.example.b2201024_1010a;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    ActivityResultLauncher<Intent> launcher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        EditText inputID = (EditText) findViewById(R.id.editTextText);
        EditText inputPW = (EditText) findViewById(R.id.editTextText2);
        Button btnLogin = (Button) findViewById(R.id.button);
        TextView statusText = (TextView) findViewById(R.id.textView);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SubActivity.class);
                intent.putExtra("ID", inputID.getText().toString());
                intent.putExtra("PW", inputPW.getText().toString());
                //startActivity(intent);
                launcher.launch(intent);
            }
        });

        launcher = registerForActivityResult(new ActivityResultContracts.
                StartActivityForResult(), result->{
            if (result.getResultCode() == Activity.RESULT_OK){
                Intent data = result.getData();
                String statData = data.getStringExtra("STATUS");
                statusText.setText(statData);

                if(statData.equals("로그인 성공")){
                    inputID.setVisibility(View.INVISIBLE);
                    inputPW.setVisibility(View.INVISIBLE);
                    btnLogin.setVisibility(View.INVISIBLE);
                }
            }
        });
    }
}