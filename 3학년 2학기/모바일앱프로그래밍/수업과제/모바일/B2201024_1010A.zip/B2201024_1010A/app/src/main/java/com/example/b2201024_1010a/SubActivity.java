package com.example.b2201024_1010a;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SubActivity extends AppCompatActivity {

    String id;
    String pw;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sub);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        TextView displayID = (TextView) findViewById(R.id.textView4);
        TextView displayPW = (TextView) findViewById(R.id.textView5);
        Button button = (Button) findViewById(R.id.button2);

        Intent intent = getIntent();
        if (intent != null){
            id = intent.getStringExtra("ID");
            pw = intent.getStringExtra("PW");

            displayID.setText("아이디 : " + id);
            displayPW.setText("비밀번호 : " + pw);
        }

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent returnIntent = new Intent();

                if (id.equals("aaa") && pw.equals("aaa"))
                    returnIntent.putExtra("STATUS", "로그인 성공");
                else
                    returnIntent.putExtra("STATUS", "로그인 실패");

                setResult(RESULT_OK, returnIntent);
                finish();
            }
        });
    }
}