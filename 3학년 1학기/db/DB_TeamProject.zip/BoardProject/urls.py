from django.urls import path
from . import views

urlpatterns = [
    path('', views.main_page, name='main_page'),
    path('list/', views.post_list, name='post_list'),
    path('write/', views.post_write, name='post_write'),
    path('post/<int:post_id>/', views.post_detail, name='post_detail'), 
]