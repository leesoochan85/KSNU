from django.shortcuts import render, get_object_or_404
from .models import Post

def main_page(request):
    return render(request, 'MainPage.html')

def post_list(request):
    return render(request, 'BoardList.html')

def post_write(request):
    return render(request, 'BoardWrite.html')

def post_detail(request, post_id):
    # 더미 데이터, 실제 연동 필요
    post = {
        'id': post_id,
        'title': '가짜 제목입니다',
        'writer': '관리자',
        'created_at': '2025-04-06',
        'content': '가짜 내용입니다. '
    }

    return render(request, 'BoardDetail.html', {'post': post})