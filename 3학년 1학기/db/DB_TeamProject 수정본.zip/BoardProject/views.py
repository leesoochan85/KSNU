from django.shortcuts import render, get_object_or_404, redirect
from .models import Post
from django.http import JsonResponse
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import authenticate, login
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from .forms import SignUpForm

def boardlist(request):
    return render(request, 'boardlist.html')

def boardwrite(request):
    return render(request, 'boardwrite.html')

def main_page(request):
    return render(request, 'MainPage.html')

@login_required
def post_list(request):
    posts = Post.objects.all().order_by('-date')  # 글 전체를 날짜 내림차순으로 가져오기
    return render(request, 'BoardList.html', {'posts': posts})

def post_list_api(request):
    posts = Post.objects.all().order_by('-date')
    data = []
    for post in posts:
        data.append({
            'id': post.id,
            'title': post.title,
            'writer': post.writer,
            'date': post.date.strftime('%Y-%m-%d %H:%M')
        })
    return JsonResponse(data, safe=False)

@login_required
def post_write(request):
    if request.method == "POST":
        title = request.POST.get('title')
        content = request.POST.get('content')
        writer = request.POST.get('writer')
        
        Post.objects.create(title=title, content=content, writer=writer)
        return redirect('post_list')  # 저장 후 목록 페이지로 이동
    return render(request, 'BoardWrite.html')

def post_detail(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    return render(request, 'BoardDetail.html', {'post': post})

@login_required
def mypage(request):
    user = request.user  # 현재 로그인한 사용자
    return render(request, 'mypage.html', {'user': user})

def signup(request):
    if request.method == "POST":
        form = SignUpForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')  # 가입 후 로그인 페이지로
    else:
        form = SignUpForm()
    return render(request, 'signup.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect('/')  # 로그인 성공하면 메인 페이지로
        else:
            messages.error(request, '아이디 또는 비밀번호가 틀렸습니다.')

    return render(request, 'registration/login.html')