from django.db import models
from django.contrib.auth.models import User
class Post(models.Model): #이부분 실제 DB로 연결할 필요가 있습니다. 글 번호 등, 필요한 요소 더 넣을 수 있습니다.
    title = models.CharField(max_length=200)
    content = models.TextField()
    writer = models.ForeignKey(User, on_delete=models.SET_NULL,null=True)
    date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title