# account/views.py
from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import login

def signup_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        password2 = request.POST['password2']

        if password == password2:
            try:
                user = User.objects.create_user(username=username, password=password)
                login(request, user)
                return redirect('home')  # 로그인 후 이동할 페이지
            except:
                return render(request, 'account/signup.html', {'error': 'Username already exists'})
        else:
            return render(request, 'account/signup.html', {'error': 'Passwords do not match'})
    else:
        return render(request, 'account/signup.html')
